// Placeholder for seed script
console.log('Seed script placeholder')